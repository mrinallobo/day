from aioflask import Flask, request
from binance.client import AsyncClient
from binance.enums import *
import aiohttp

app = Flask(__name__)

# Master account API credentials
master_api_key = 'MASTER_API_KEY'
master_api_secret = 'MASTER_API_SECRET'

# Slave accounts API credentials and ratios
slave_accounts = [
    {'api_key': 'SLAVE_API_KEY_1', 'api_secret': 'SLAVE_API_SECRET_1', 'ratio': 0.5},
    {'api_key': 'SLAVE_API_KEY_2', 'api_secret': 'SLAVE_API_SECRET_2', 'ratio': 0.3},
    # Add more slave accounts as needed
]

# Discord webhook URL
discord_webhook_url = 'YOUR_DISCORD_WEBHOOK_URL'

async def send_discord_message(message):
    async with aiohttp.ClientSession() as session:
        payload = {'content': message}
        async with session.post(discord_webhook_url, json=payload) as response:
            await response.text()

async def place_spot_order(client, symbol, side, quantity):
    try:
        order = await client.create_order(
            symbol=symbol,
            side=side,
            type=ORDER_TYPE_MARKET,
            quantity=quantity
        )
        print(f"Spot order placed: {order}")
        await send_discord_message(f"New spot order placed: {order}")
    except Exception as e:
        print(f"Error placing spot order: {e}")
        await send_discord_message(f"Error placing spot order: {e}")

async def place_futures_order(client, symbol, side, quantity):
    try:
        order = await client.futures_create_order(
            symbol=symbol,
            side=side,
            type=ORDER_TYPE_MARKET,
            quantity=quantity
        )
        print(f"Futures order placed: {order}")
        await send_discord_message(f"New futures order placed: {order}")
    except Exception as e:
        print(f"Error placing futures order: {e}")
        await send_discord_message(f"Error placing futures order: {e}")

async def close_futures_position(client, symbol):
    try:
        positions = await client.futures_position_information(symbol=symbol)
        for position in positions:
            if float(position['positionAmt']) != 0:
                side = SIDE_BUY if position['positionSide'] == 'SHORT' else SIDE_SELL
                quantity = abs(float(position['positionAmt']))
                order = await client.futures_create_order(
                    symbol=symbol,
                    side=side,
                    type=ORDER_TYPE_MARKET,
                    quantity=quantity
                )
                print(f"Futures position closed: {order}")
                await send_discord_message(f"Futures position closed: {order}")
    except Exception as e:
        print(f"Error closing futures position: {e}")
        await send_discord_message(f"Error closing futures position: {e}")

@app.route('/webhook', methods=['POST'])
async def handle_webhook():
    data = await request.get_json()
    action = data['action']
    symbol = data['symbol']
    exit_type = data.get('exit_type')

    # Create master account client
    async with AsyncClient(master_api_key, master_api_secret) as master_client:
        if action == 'buy':
            # Get master account balance
            master_balance = await master_client.get_asset_balance(asset=symbol.split('USDT')[0])['free']
            # Place order on master account
            master_quantity = float(master_balance) * 0.01  # Adjust the percentage as needed
            await place_spot_order(master_client, symbol, SIDE_BUY, master_quantity)
            # Place orders on slave accounts
            for account in slave_accounts:
                async with AsyncClient(account['api_key'], account['api_secret']) as client:
                    slave_quantity = master_quantity * account['ratio']
                    await place_spot_order(client, symbol, SIDE_BUY, slave_quantity)
        elif action == 'sell':
            # Get master account balance
            master_balance = (await master_client.futures_account_balance())[0]['balance']
            # Place order on master account
            master_quantity = float(master_balance) * 0.01  # Adjust the percentage as needed
            await place_futures_order(master_client, symbol, SIDE_SELL, master_quantity)
            # Place orders on slave accounts
            for account in slave_accounts:
                async with AsyncClient(account['api_key'], account['api_secret']) as client:
                    slave_quantity = master_quantity * account['ratio']
                    await place_futures_order(client, symbol, SIDE_SELL, slave_quantity)
        elif action == 'exit_long' or action == 'exit_short':
            await close_futures_position(master_client, symbol)
            for account in slave_accounts:
                async with AsyncClient(account['api_key'], account['api_secret']) as client:
                    await close_futures_position(client, symbol)

    return 'Webhook received'


# '''{
#   "action": "{{strategy.market_position}}",
#   "symbol": "{{ticker}}"
# }'''    
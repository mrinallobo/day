import math
import asyncio
import threading
from flask import Flask, request, jsonify
from binance.client import AsyncClient
from binance.enums import *
from binance.exceptions import BinanceAPIException

app = Flask(__name__)

api_key = 'vknq96vBmFZyBpFgMrOJ7HNVhlnO1qJSs2Kdyg40WNO2oudQSWEFAmwAQYrEIm0L'
api_secret = 'qQdTKB4wEyjRKWJwpM8CW9sRWjIGPBeODa34LRYlJtGbl4kaF9l6BvCJs29vlZlk'

def async_to_sync(func):
    """Decorator to run an async function in a separate thread."""
    def wrapper(*args, **kwargs):
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        result = loop.run_until_complete(func(*args, **kwargs))
        loop.close()
        return result
    return wrapper

def adjust_quantity(quantity, step_size):
    try:
        step_size = float(step_size)
        if step_size <= 0:
            raise ValueError(f"Invalid step size: {step_size}. Step size must be greater than zero.")
        precision = int(-math.log10(step_size))
        return round(quantity, precision)
    except ValueError as e:
        print(e)
        return quantity  # Fallback to the unadjusted quantity if there's an error

async def get_lot_sizes(client, symbol):
    exchange_info = await client.get_exchange_info()
    lot_sizes = {'lot_size': '0.01', 'market_lot_size': '0.01'}  # Safe default values
    for s in exchange_info['symbols']:
        if s['symbol'] == symbol:
            for f in s['filters']:
                if f['filterType'] == 'LOT_SIZE':
                    lot_sizes['lot_size'] = f['stepSize']
                elif f['filterType'] == 'MARKET_LOT_SIZE' and float(f['stepSize']) > 0:
                    lot_sizes['market_lot_size'] = f['stepSize']
    return lot_sizes

@async_to_sync
async def process_order(action, symbol, tp1, tp2, tp3, sl):
    client = None
    try:
        client = AsyncClient(api_key, api_secret, testnet=True)
        lot_sizes = await get_lot_sizes(client, symbol)
        if action == 'buy':
            balance_response = await client.get_asset_balance(asset='USDT')
            balance = balance_response['free']
            quantity = float(balance) * 0.01
            # Use the appropriate step size:
            quantity = 0.1
            step_size = lot_sizes['market_lot_size'] if float(lot_sizes['market_lot_size']) > 0 else lot_sizes['lot_size']
            quantity = adjust_quantity(quantity, step_size)
            try:
                await place_spot_order(client, symbol, SIDE_BUY, quantity)
            except BinanceAPIException as e:
                if e.code == -1013:  # Filter failure: MARKET_LOT_SIZE
                    print(f"Error placing spot order: {e}")
                    return
                else:
                    raise
            tp_qty1 = adjust_quantity(quantity // 3, step_size)
            tp_qty2 = adjust_quantity(quantity // 3, step_size)
            tp_qty3 = adjust_quantity(quantity - (tp_qty1 + tp_qty2), step_size)
            await place_limit_order(client, symbol, SIDE_SELL, tp_qty1, tp1)
            await place_limit_order(client, symbol, SIDE_SELL, tp_qty2, tp2)
            await place_limit_order(client, symbol, SIDE_SELL, tp_qty3, tp3)
            await place_stop_loss_limit_order(client, symbol, quantity, sl)
        elif action == 'sell':
            await cancel_all_orders(client, symbol)
            await square_off_positions(client, symbol)
    finally:
        if client:
            await client.close_connection()

@app.route('/webhook', methods=['POST'])
def handle_webhook():
    data = request.get_json()
    action = data['action']
    symbol = data['symbol']
    tp1 = data['tp1']
    tp2 = data['tp2']
    tp3 = data['tp3']
    sl = data['sl']
    process_order(action, symbol, tp1, tp2, tp3, sl)
    return jsonify({'status': 'success', 'message': 'Webhook processed'})

async def place_spot_order(client, symbol, side, quantity):
    lot_sizes = await get_lot_sizes(client, symbol)
    step_size = lot_sizes['market_lot_size'] if float(lot_sizes['market_lot_size']) > 0 else lot_sizes['lot_size']
    quantity = adjust_quantity(quantity, step_size)
    order = await client.create_order(symbol=symbol, side=side, type=ORDER_TYPE_MARKET, quantity=quantity)
    print(f"Spot order placed: {order}")

async def place_limit_order(client, symbol, side, quantity, price):
    order = await client.create_order(symbol=symbol, side=side, type=ORDER_TYPE_LIMIT, timeInForce=TIME_IN_FORCE_GTC, quantity=quantity, price=price)
    print(f"Limit order placed at {price}: {order}")

async def place_stop_loss_limit_order(client, symbol, quantity, price):
    order = await client.create_order(symbol=symbol, side=SIDE_SELL, type=ORDER_TYPE_STOP_LOSS_LIMIT, timeInForce=TIME_IN_FORCE_GTC, stopPrice=price, price=price, quantity=quantity)
    print(f"Stop-loss limit order placed at {price}: {order}")

async def cancel_all_orders(client, symbol):
    await client.cancel_open_orders(symbol=symbol)
    print("All open orders cancelled.")

async def square_off_positions(client, symbol):
    asset = symbol.split('USDT')[0]
    quantity = float((await client.get_asset_balance(asset=asset))['free'])
    if quantity > 0:
        await place_spot_order(client, symbol, SIDE_SELL, quantity)
    print("All positions squared off.")

if __name__ == "__main__":
    app.run(debug=True)
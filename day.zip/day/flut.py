from flask import Flask, render_template, request, redirect, url_for, flash
from flask_socketio import SocketIO, emit
import random
import time
from threading import Thread
import signal
import sys

app = Flask(__name__)
app.secret_key = 'oops' # Required for flash messages
socketio = SocketIO(app)

# Initial list of tickers
tickers = ['MARA', 'AAPL', 'SPY']

# Function to generate a random PnL value
def generate_random_pnl():
    return random.randint(-5000, 20000)

# Background task to emit PnL updates
def background_task():
    while True:
        pnl = generate_random_pnl()
        socketio.emit('pnl_update', {'pnl': pnl})
        time.sleep(1) # Update every second

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        action = request.form.get('action')
        ticker_name = request.form.get('tickerName')
        selected_tickers = request.form.getlist('selectedTickers')

        if action == 'add' and ticker_name:
            if ticker_name not in tickers:
                tickers.append(ticker_name)
        elif action == 'remove' and ticker_name:
            if ticker_name in tickers:
                tickers.remove(ticker_name)

        if action == 'start':
            print("Started")
            flash("Started", category='success')
        elif action == 'stop':
            print("Stopped")
            flash("Stopped", category='danger')
        elif action == 'square_off':
            print("Square Off")
            flash("Square Off", category='warning')

        if selected_tickers:
            print("Running tickers for the day:", selected_tickers)
            # Here you can add the logic to actually run the tickers

        return redirect(url_for('index'))

    return render_template('index.html', tickers=tickers)

def signal_handler(sig, frame):
    print('You pressed Ctrl+C!')
    # Here you can add any cleanup code
    sys.exit(0)

# Register the signal handler
signal.signal(signal.SIGINT, signal_handler)

if __name__ == '__main__':
    # Start the background task
    Thread(target=background_task).start()
    socketio.run(app, debug=True)

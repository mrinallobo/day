from quart import Quart, request, jsonify
import httpx
import asyncio

app = Quart(__name__)

API_KEY = 'vknq96vBmFZyBpFgMrOJ7HNVhlnO1qJSs2Kdyg40WNO2oudQSWEFAmwAQYrEIm0L'
API_SECRET = 'qQdTKB4wEyjRKWJwpM8CW9sRWjIGPBeODa34LRYlJtGbl4kaF9l6BvCJs29vlZlk'
BASE_URL = 'https://testnet.binance.vision/api'

# Initialize the HTTP client for async operations
client = httpx.AsyncClient()

async def get_open_orders(symbol):
    url = f"{BASE_URL}/api/v3/openOrders?symbol={symbol}"
    headers = {"X-MBX-APIKEY": API_KEY}
    response = await client.get(url, headers=headers)
    return response.json()

async def cancel_order(symbol, orderId):
    url = f"{BASE_URL}/api/v3/order"
    headers = {"X-MBX-APIKEY": API_KEY}
    params = {"symbol": symbol, "orderId": orderId}
    response = await client.delete(url, headers=headers, params=params)
    return response.json()

async def create_order(symbol, side, type, quantity):
    url = f"{BASE_URL}/api/v3/order"
    headers = {"X-MBX-APIKEY": API_KEY}
    data = {
        "symbol": symbol,
        "side": side,
        "type": type,
        "quantity": quantity
    }
    response = await client.post(url, headers=headers, json=data)
    return response.json()

@app.route('/webhook', methods=['POST'])
async def webhook():
    data = await request.get_json()
    symbol = data['symbol']
    action = data['action'].lower()

    if action == 'buy':
        quantity = 0.1  # Define the quantity for the market order
        order = await create_order(symbol, "BUY", "MARKET", quantity)
        print("Market Order Response:", order)

        # Example of handling orders in parallel
        tasks = [
            create_order(symbol, "SELL", "LIMIT", quantity / 3, price)
            for price in [data['tp1'], data['tp2'], data['tp3']]
        ]
        results = await asyncio.gather(*tasks)
        print("TP Orders:", results)

    return jsonify({'status': 'completed'})

if __name__ == '__main__':
    app.run()

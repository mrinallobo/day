# import requests

# url = 'http://127.0.0.1:5000/webhook'
# data = {
#     "action": "sell",
#     "symbol": "BTCUSDT",
#     "tp1": "65000",
#     "tp2": "66000",
#     "tp3": "67000",
#     "sl": "58000"
# }

# response = requests.post(url, json=data)
# print(response.text)

import requests
import time

# Base URL of your Flask application
url = 'http://127.0.0.1:5000/webhook'

# Function to send a POST request to the webhook
def send_signal(data):
    response = requests.post(url, json=data)
    print(response.text)

# Define the data for each action
buy_data = {
    "action": "buy",
    "symbol": "BTCUSDT",
    "tp1": "70000",
    "tp2": "71000",
    "tp3": "72000",
    "price": "69000"
}

sl_buy_data = {
    "action": "exit_long",
    "symbol": "BTCUSDT",
    "price": "67000"
}

sell_data = {
    "action": "sell",
    "symbol": "BTCUSDT",
    "tp1": "65000",
    "tp2": "66000",
    "tp3": "67000",
    "price": "67000"
}

sl_sell_data = {
    "action": "exit_short",
    "symbol": "BTCUSDT",
    "price": "67000"
}

# Send buy signal
send_signal(buy_data)
time.sleep(5)  # Wait for 5 seconds

# Send SL buy signal
send_signal(sl_buy_data)
time.sleep(5)  # Wait for 5 seconds

send_signal(sell_data)
time.sleep(5) 
# # Send sell signal
send_signal(sl_sell_data)
time.sleep(5)
 # Wait for 5 seconds

# Send SL sell signal


import csv
import asyncio
from flask import Flask, request, render_template
from binance.client import AsyncClient, Client
from binance.enums import *
import math
import decimal
app = Flask(__name__)

USER_FILE = 'users.csv'

# Load and cache user data (consider refreshing periodically)
USERS = []

def load_users():
    global USERS
    USERS = []
    try:
        with open(USER_FILE, 'r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                # Convert accountPercentage to float when loading
                row['accountPercentage'] = float(row['accountPercentage'])
                USERS.append(row)
    except FileNotFoundError:
        pass
    return USERS

load_users()  # Load initially

def save_users(users):
    with open(USER_FILE, 'w', newline='') as file:
        fieldnames = ['username', 'api_key', 'api_secret', 'trading_preference', 'accountPercentage']
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(users)

async def get_async_client(api_key, api_secret):
    return await AsyncClient.create(api_key, api_secret, testnet=True)  # Change testnet as needed

def get_sync_client(api_key, api_secret):
    return Client(api_key, api_secret, testnet=True)  # Change testnet as needed


async def cancel_open_orders(client, symbol, futures=False):
    try:
        if futures:
            open_orders = client.futures_get_open_orders(symbol=symbol)
            for order in open_orders:
                client.futures_cancel_order(symbol=symbol, orderId=order['orderId'])
        else:
            open_orders = await client.get_open_orders(symbol=symbol)
            for order in open_orders:
                await client.cancel_order(symbol=symbol, orderId=order['orderId'])
    except Exception as e:
        print(f"Error cancelling open orders: {e}")

async def place_order(client, symbol, side, quantity, futures=False):
    attempt = 0
    max_attempts = 10
    while attempt < max_attempts:
        try:
            if futures:
                order = client.futures_create_order(
                    symbol=symbol,
                    side=side,
                    type=FUTURE_ORDER_TYPE_MARKET,
                    quantity=quantity
                )
            else:
                order = await client.create_order(
                    symbol=symbol,
                    side=side,
                    type=ORDER_TYPE_MARKET,
                    quantity=quantity
                )
            print(f"{'Futures' if futures else 'Spot'} Order Placed: {order}")
            return order
        except Exception as e:
            print(f"Error placing {'futures' if futures else 'spot'} order: {e}")
            if 'precision' in str(e).lower():
                quantity = round(quantity - 10**-attempt, attempt)
                attempt += 1
            else:
                raise e

async def close_position(client, symbol):
    try:
        positions = client.futures_position_information(symbol=symbol)
        for pos in positions:
            if float(pos['positionAmt']) != 0:
                side = SIDE_BUY if pos['positionSide'] == 'SHORT' else SIDE_SELL
                quantity = abs(float(pos['positionAmt']))
                await place_order(client, symbol, side, quantity, futures=True)
    except Exception as e:
        print(f"Error closing futures position: {e}")

def adjust_quantity(quantity, symbol, client, futures=False):
    """Adjusts the quantity to the minimum lot size and precision for the given symbol."""
    info = client.get_symbol_info(symbol)
    filters = {f['filterType']: f for f in info['filters']}
    step_size = filters['LOT_SIZE']['stepSize']
    max_precision = abs(decimal.Decimal(step_size).as_tuple().exponent)
    print(max_precision,"Max precision")
    # Convert quantity to a Decimal with max_precision
    quantity = decimal.Decimal(str(quantity)).quantize(decimal.Decimal('0.' + '0'*(max_precision-1) + '1'), rounding=decimal.ROUND_DOWN)
    
    # Adjust quantity to step size
    step_size_dec = decimal.Decimal(step_size)
    quantity = quantity - (quantity % step_size_dec)  # Round down to step size
    
    # Ensure it's not below minQty
    min_qty = decimal.Decimal(filters['LOT_SIZE']['minQty'])
    quantity = max(quantity, min_qty)
    quantity = round(quantity,max_precision-5)
    return quantity

def round_down( client, quantity, symbol):
    info = client.get_symbol_info(symbol)
    step_size = [float(_['stepSize']) for _ in info['filters'] if _['filterType'] == 'LOT_SIZE'][0]
    step_size = '%.8f' % step_size
    step_size = step_size.rstrip('0')
    decimals = len(step_size.split('.')[1])
    print(math.floor(quantity * 10 ** decimals) / 10 ** decimals,"Quantity rounded")
    return math.floor(quantity * 10 ** decimals) / 10 ** decimals

async def check_spot_orders(client, symbol):
    try:
        open_orders = await client.get_open_orders(symbol=symbol)
        if len(open_orders) > 0:
            return True
        else:
            return False
    except Exception as e:
        print(f"Error checking spot orders: {e}")
        return False

async def close_spot_position(client, symbol):
    try:
        # Get the base asset of the symbol
        base_asset = symbol[:-3]  # Remove the last 3 characters (usually USDT or BTC)
        
        # Get the account balance
        account_info = await client.get_account()
        
        # Find the balance of the base asset
        for asset in account_info['balances']:
            if asset['asset'] == base_asset:
                quantity = float(asset['free'])
                
                # If a balance is found and it's greater than 0, place a market sell order to close the position
                if quantity > 0:
                    order = await client.order_market_sell(
                        symbol=symbol,
                        quantity=quantity
                    )
                    print(f"Spot position closed for {symbol}. Order details: {order}")
                    return True
        
        # If no balance is found or the balance is 0, no position exists
        print(f"No spot position found for {symbol}.")
        return False
    
    except Exception as e:
        print(f"Error closing spot position for {symbol}: {e}")
        return False

async def handle_signal(data):
    global USERS
    action = data['action'].lower()
    symbol = data['symbol']
    price = float(data['price'])
    print(price, "Is the price")
    
    for user in USERS:
        try:
            # Create both spot and futures clients
            spot_client = await get_async_client(user['api_key'], user['api_secret'])
            futures_client = get_sync_client(user['api_key'], user['api_secret'])

            # --- Calculate quantity based on account percentage and risk management ---
            if user['trading_preference'] == 'both':
                account_balance = futures_client.futures_account_balance()  # Futures balance
                balance_to_use = float(next((bal['balance'] for bal in account_balance if bal['asset'] == 'USDT'), 0)) * (user['accountPercentage'] / 100)
                print(balance_to_use, "Balance to use")
            else:
                account_balance = await spot_client.get_account()  # Spot balance for 'long' users
                balance_to_use = float(next((bal['free'] for bal in account_balance['balances'] if bal['asset'] == 'USDT'), 0)) * (user['accountPercentage'] / 100)
                print(balance_to_use, "Balance to use")
            
            # Placeholder, adjust based on risk and symbol price
            quantity = balance_to_use / price
            print(quantity, "Quantity")
            
            if action == 'buy':
                
                tp_prices = [data['tp1'], data['tp2'], data['tp3']]
                if user['trading_preference'] in ('both', 'long'):
                    if user['trading_preference'] == 'both':
                        # Cancel open orders for futures
                        await close_position(futures_client, symbol)
                        await cancel_open_orders(futures_client, symbol, futures=True)
                        
                        # Long on futures for 'both' preference
                        adjusted_quantity = adjust_quantity(quantity, symbol, futures_client, futures=True)
                        print(adjusted_quantity, "Adjusted Quantity")
                        await place_order(futures_client, symbol, SIDE_BUY, adjusted_quantity, futures=True) 
                        tp_quantity = round(adjusted_quantity / 3, 3)
                        for price in tp_prices:
                            tp_order = await place_order(futures_client, symbol, SIDE_SELL, tp_quantity, futures=True)
                            print(tp_order)
                    else:
                        # Cancel open orders for spot
                        await cancel_open_orders(spot_client, symbol)
                        
                        # Long on spot for 'long' preference
                        adjusted_quantity = adjust_quantity(quantity, symbol, spot_client)
                        print(adjusted_quantity, "Adjusted Quantity")
                        await place_order(spot_client, symbol, SIDE_BUY, adjusted_quantity)
                        tp_quantity = round(adjusted_quantity / 3, 3)
                        for price in tp_prices:
                            tp_order = await place_order(spot_client, symbol, SIDE_SELL, adjusted_quantity)
                            print(tp_order) 
            elif action == 'sell':
                if await check_spot_orders(spot_client, symbol):
                    await cancel_open_orders(spot_client, symbol)
                    await close_spot_position(spot_client, symbol)
                await close_position(futures_client, symbol)
                tp_prices = [data['tp1'], data['tp2'], data['tp3']]
                print("Sell triggered")
                if user['trading_preference'] == 'both':
                    # Cancel open orders for futures
                    await cancel_open_orders(futures_client, symbol, futures=True)
                    
                    adjusted_quantity = adjust_quantity(quantity, symbol, futures_client, futures=True)
                    print(adjusted_quantity, "Adjusted Quantity")
                    await place_order(futures_client, symbol, SIDE_SELL, adjusted_quantity, futures=True) 
                    tp_quantity = round(adjusted_quantity / 3, 3)
                    for price in tp_prices:
                        tp_order = await place_order(futures_client, symbol, SIDE_SELL, tp_quantity, futures=True)
                        print(tp_order)
            elif action in ('exit_long', 'exit_short'):
                if user['trading_preference'] in ('both', 'long'):  # 'long' users might have spot positions to close
                    if user['trading_preference'] == 'both':
                        await close_position(futures_client, symbol)
                    else:
                        # Close spot positions for 'long' users
                        await close_spot_position(spot_client, symbol) # Assuming market sell to close 
        except Exception as e:
            print(f"Error processing signal for user {user['username']}: {e}")
        finally:
            await spot_client.session.close()


@app.route('/')
async def index():
    global USERS
    users = load_users()
    return render_template('index.html', users=USERS)

@app.route('/add_user', methods=['POST'])
def add_user():
    global USERS
    try:
        username = request.form['username']
        api_key = request.form['apiKey']
        api_secret = request.form['apiSecret']
        trading_preference = request.form['tradingPreference']
        account_percentage = float(request.form['accountPercentage'])

        user = {
            'username': username,
            'api_key': api_key,
            'api_secret': api_secret,
            'trading_preference': trading_preference,
            'accountPercentage': account_percentage
        }

        USERS.append(user)
        save_users(USERS)
        return {'success': True}, 200
    except KeyError as e:
        return {'error': f'Missing field: {e.args[0]}'}, 400
    except ValueError:
        return {'error': 'Invalid account percentage. Please enter a number.'}, 400

@app.route('/remove_user', methods=['POST'])
def remove_user():
    global USERS
    data = request.get_json()
    index = data['index']

    del USERS[index]
    save_users(USERS)

    return {'success': True}

@app.route('/user_list')
def user_list():
    global USERS
    return {'users': USERS}

@app.route('/webhook', methods=['POST'])
async def webhook():
    data = request.get_json()
    await handle_signal(data)
    return 'Webhook received', 200

if __name__ == '__main__':
    # app.run(debug=True) # use this for debugging and testing
    app.run() # use this for production

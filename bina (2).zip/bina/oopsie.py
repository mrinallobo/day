from binance.client import Client
from binance.enums import *
import time
api_key = 'vknq96vBmFZyBpFgMrOJ7HNVhlnO1qJSs2Kdyg40WNO2oudQSWEFAmwAQYrEIm0L'
api_secret = 'qQdTKB4wEyjRKWJwpM8CW9sRWjIGPBeODa34LRYlJtGbl4kaF9l6BvCJs29vlZlk'
client = Client(api_key, api_secret)
client.API_URL = 'https://testnet.binance.vision/api'

# Adjust client to handle drift in server time automatically
client.TIME_OFFSET = True

info = client.get_account()
# print(info)
# order = client.create_order(
#     symbol='BTCUSDT',
#     side=Client.SIDE_BUY,
#     type=Client.ORDER_TYPE_MARKET,
#     quantity=0.01  # Adjust the quantity according to the minimum requirements for the pair
# )

# print(order)


# def place_limit_buy_order(client, symbol, price, quantity):
#     """Places a limit buy order on Binance."""
#     try:
#         order = client.create_order(
#             symbol=symbol,
#             side=Client.SIDE_BUY,
#             type=Client.ORDER_TYPE_LIMIT,
#             timeInForce=Client.TIME_IN_FORCE_GTC,  # Good 'Til Canceled
#             quantity=quantity,
#             price=str(price)
#         )
#         return order
#     except Exception as e:
#         print(f"An error occurred while placing the limit buy order: {str(e)}")
#         return None

# # Example usage
# # Assuming the minimum quantity for BTCUSDT can be met with this value; adjust as necessary.
# # Please check the current minimum quantity and precision rules on Binance.
# quantity = '0.001'  # Example quantity; ensure this meets Binance's minimum quantity requirement for the pair.
# price = '21000'  # The price at which you want to buy BTC.
# symbol = 'BTCUSDT'

# order_response = place_limit_buy_order(client, symbol, price, quantity)
# print(order_response)



# def check_open_orders(client, symbol):
#     """Fetches and returns all current open orders for a specified symbol on Binance spot."""
#     try:
#         open_orders = client.get_open_orders(symbol=symbol)
#         return open_orders
#     except Exception as e:
#         print(f"Failed to fetch open orders for {symbol}: {str(e)}")
#         return []



# def cancel_all_orders(client, symbol):
#     """Cancels all open orders for the specified symbol on Binance spot."""
#     try:
#         # Fetch all open orders for the specified symbol
#         open_orders = client.get_open_orders(symbol=symbol)
        
#         if not open_orders:
#             print(f"No open orders found for {symbol}")
#             return []
        
#         # Cancel each open order individually
#         canceled_orders = []
#         for order in open_orders:
#             order_id = order['orderId']
#             try:
#                 canceled_order = client.cancel_order(symbol=symbol, orderId=order_id)
#                 canceled_orders.append(canceled_order)
#                 print(f"Canceled order {order_id} for {symbol}")
#             except Exception as e:
#                 print(f"Failed to cancel order {order_id} for {symbol}: {str(e)}")
        
#         return canceled_orders
#     except Exception as e:
#         print(f"Failed to retrieve open orders for {symbol}: {str(e)}")
#         return None



# def square_off_position(client, symbol):
#     """Squares off all holdings for the specified symbol by placing a market sell order on Binance spot."""
#     try:
#         # Get current balance for the base asset (e.g., BTC in BTCUSDT)
#         base_asset = symbol[:-4]
#         balance = client.get_asset_balance(asset=base_asset)
#         quantity = float(balance['free'])

#         if quantity > 0:
#             # Place a market sell order
#             result = client.create_order(
#                 symbol=symbol,
#                 side=Client.SIDE_SELL,
#                 type=Client.ORDER_TYPE_MARKET,
#                 quantity=quantity
#             )
#             print(f"Market sell order placed to square off {symbol}: {result}")
#             return result
#         else:
#             print(f"No available balance to square off for {symbol}")
#             return None

#     except Exception as e:
#         print(f"Failed to square off position for {symbol}: {str(e)}")
#         return None


# quantity = '0.001'  # Example quantity; ensure this meets Binance's minimum quantity requirement for the pair.
# price = '21000'  # The price at which you want to buy BTC.
# symbol = 'BTCUSDT'

# order_response = place_limit_buy_order(client, symbol, price, quantity)
# print(order_response)

# orders = check_open_orders(client, 'BTCUSDT')
# print("Open Orders:", orders)

# # Cancel all open orders
# cancel_all_orders(client, 'BTCUSDT')

# # Square off all holdings (sell everything)
# square_off_position(client, 'BTCUSDT')

def place_market_buy_order(client, symbol, quantity):
    """Place a market buy order."""
    return client.create_order(
        symbol=symbol,
        side=SIDE_BUY,
        type=ORDER_TYPE_MARKET,
        quantity=quantity
    )

def place_limit_sell_order(client, symbol, quantity, price):
    """Place a limit sell order."""
    return client.create_order(
        symbol=symbol,
        side=SIDE_SELL,
        type=ORDER_TYPE_LIMIT,
        timeInForce=TIME_IN_FORCE_GTC,
        quantity=quantity,
        price=price
    )

def place_stop_loss_order(client, symbol, quantity, stop_price):
    """Place a stop loss order."""
    # Retrieve balance to confirm available quantity
    base_asset = symbol[:-4]
    balance = client.get_asset_balance(asset=base_asset)
    print(balance)
    available_qty = float(balance['free'])

    # Use the lesser of the intended quantity or the available quantity
    quantity_to_use = min(available_qty, quantity)

    # Proceed only if there's sufficient quantity to place the stop loss order
    if quantity_to_use > 0:
        return client.create_order(
            symbol=symbol,
            side=SIDE_SELL,
            type=ORDER_TYPE_STOP_LOSS_LIMIT,
            timeInForce=TIME_IN_FORCE_GTC,
            quantity=quantity_to_use,
            stopPrice=stop_price,
            price=str(float(stop_price) * 0.99)  # Set slightly below the stopPrice for safety
        )
    else:
        print(f"Insufficient quantity available for placing stop loss order: {available_qty}")
        return None


def execute_trading_sequence(client, symbol, entry_qty, tp_prices, sl_price, action_delay=10):
    """Execute a trading sequence including a buy order followed by a configurable delay and a sell order."""
    # Place buy order
    print("Placing buy order...")
    buy_order = place_market_buy_order(client, symbol, entry_qty)
    print("Buy order response:", buy_order)

    # Place TP and SL orders
    quantity_per_tp = round(entry_qty / len(tp_prices), 6)  # Adjust precision as necessary
    tp_orders = [place_limit_sell_order(client, symbol, quantity_per_tp, price) for price in tp_prices]
    sl_order = place_stop_loss_order(client, symbol, entry_qty, sl_price)
    print("TP and SL orders placed.")

    # Wait for a specified delay before the next action
    print(f"Waiting {action_delay} seconds before placing opposing order...")
    time.sleep(action_delay)

    # Optionally, place a market sell order to simulate an opposing trade
    sell_qty = entry_qty  # This should be adjusted based on your strategy needs
    print("Placing market sell order...")
    sell_order = place_market_buy_order(client, symbol, sell_qty)  # This should be a sell order, adjust as necessary
    print("Sell order response:", sell_order)

# Example usage
symbol = 'BTCUSDT'
entry_qty = 0.003  # Total quantity to buy
tp_prices = ['66700', '69000', '68300']  # Example TP prices
sl_price = '61000'  # Example SL price

execute_trading_sequence(client, symbol, entry_qty, tp_prices, sl_price, action_delay=10)
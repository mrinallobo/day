from flask import Flask, request, jsonify
import time
from binance.client import Client
from binance.enums import *

app = Flask(__name__)

# API keys for spot trading
API_KEY = 'vknq96vBmFZyBpFgMrOJ7HNVhlnO1qJSs2Kdyg40WNO2oudQSWEFAmwAQYrEIm0L'
API_SECRET = 'qQdTKB4wEyjRKWJwpM8CW9sRWjIGPBeODa34LRYlJtGbl4kaF9l6BvCJs29vlZlk'

# API keys for futures trading
FUTURES_API_KEY = 'a3ea74bfe08b3b427c3f76902d30d84b4c0d9fd735857b8a318e1bc4b0a004e2'
FUTURES_API_SECRET = '97782ad4220f7c3dfdecab1e5adf09084e2f9afb7d9f6e1f1249eaf1f2007060'

# Initialize the Binance clients for spot and futures
client = Client(API_KEY, API_SECRET, testnet=True)
futures_client = Client(FUTURES_API_KEY, FUTURES_API_SECRET, testnet=True)

def adjust_quantity(quantity, symbol):
    # Fetch the full set of filters for the symbol
    info = client.get_symbol_info(symbol)
    filters = {f['filterType']: f for f in info['filters']}

    # Minimum, maximum, and step size
    min_qty = float(filters['LOT_SIZE']['minQty'])
    max_qty = float(filters['LOT_SIZE']['maxQty'])
    step_size = float(filters['LOT_SIZE']['stepSize'])

    # Adjust quantity to comply with min and max
    if quantity < min_qty:
        quantity = min_qty
    elif quantity > max_qty:
        quantity = max_qty

    # Adjust quantity to comply with step size
    step_factor = 1 / step_size
    quantity = (quantity * step_factor) // 1 / step_factor
    print(quantity,"Is the quantity")
    return round(quantity, 4)


@app.route('/webhook', methods=['POST'])
def webhook():
    start_time = time.time() 
    data = request.get_json()
    symbol = data['symbol']
    action = data['action'].lower()
    
    if action == 'buy':
        tp_prices = [data['tp1'], data['tp2'], data['tp3']]
        # Place market order on spot
        quantity = 0.1
        formatted_quantity = adjust_quantity(quantity, symbol)
        print("Formatted qty is ",formatted_quantity)
        order = client.order_market_buy(symbol=symbol, quantity=formatted_quantity)
        print("Market Order Response:", order)
        tp_quantity = round(formatted_quantity / 3, 4)
        
        for price in tp_prices:
            tp_order = client.order_limit_sell(symbol=symbol, quantity=tp_quantity, price=price)
            print(tp_order)

    elif action == 'sl buy':
        # Exit the quantity bought on spot
        balance = client.get_asset_balance(asset=symbol.replace('USDT', ''))
        if float(balance['free']) > 0:
            formatted_quantity = adjust_quantity(float(balance['free']), symbol)
            order = client.order_market_sell(symbol=symbol, quantity=formatted_quantity)
            print("Closing Order:", order)
    elif action == 'sl sell':
        # Exit the short position in futures
        position_info = futures_client.futures_position_information(symbol=symbol)
        short_position = next((item for item in position_info if float(item['positionAmt']) < 0), None)
        print(short_position)     
        if short_position and float(short_position['positionAmt']) < 0:
            # Calculate the quantity to close the position
            quantity_to_close = abs(float(short_position['positionAmt']))
            # Adjust the quantity to a valid step size
            formatted_quantity = adjust_quantity(quantity_to_close, symbol)
            
            # Place a market buy order to close the short position
            try:
                order = futures_client.futures_create_order(symbol=symbol, side='BUY', type='MARKET', quantity=formatted_quantity)
                print("Closing Short Position Order:", order)
            except Exception as e:
                print(f"Error closing short position: {e}")
        else:
            print("No short position found or position already closed")
    elif action == 'sell':
        tp_prices = [data['tp1'], data['tp2'], data['tp3']]
    # Calculate the total USDT available for trading
        balance = futures_client.futures_account_balance()
        asset_balance = next((item for item in balance if item['asset'] == 'USDT'), None)
        print(asset_balance)
        if asset_balance and float(asset_balance['balance']) > 0:
            quantity = float(asset_balance['balance'])
            # Adjust and format the quantity
            quantity = quantity * 0.0001  # Adjusting the quantity for risk management
            quantity = round(quantity, 4)
            print("Quantity future", quantity)
            # Adjust quantity to fit trading rules
            formatted_quantity = adjust_quantity(quantity, symbol)
            print("Formatted qty:", formatted_quantity)
            
            # Example scaling down, assuming you might want to only use a part of the adjusted quantity
            formatted_quantity *= 0.1
            print(f"Placing Futures Sell Order - Symbol: {symbol}, Quantity: {formatted_quantity}")
            formatted_quantity = round(formatted_quantity,2)
            # Place a futures market sell order
            try:
                order = futures_client.futures_create_order(symbol=symbol, side='SELL', type='MARKET', quantity=formatted_quantity)
                print("Futures Market Sell Order:", order)
            except Exception as e:
                print(f"Error placing order: {e}")


    print(f"Total processing time: {time.time() - start_time} seconds")
    return jsonify({'status': 'completed'})

if __name__ == '__main__':
    app.run(debug=True)

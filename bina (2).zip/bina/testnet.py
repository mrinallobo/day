# from flask import Flask, request, jsonify
# from binance.client import Client
# from binance.enums import *

# app = Flask(__name__)

# # Use your Binance testnet API key and secret here
# API_KEY = 'vknq96vBmFZyBpFgMrOJ7HNVhlnO1qJSs2Kdyg40WNO2oudQSWEFAmwAQYrEIm0L'
# API_SECRET = 'qQdTKB4wEyjRKWJwpM8CW9sRWjIGPBeODa34LRYlJtGbl4kaF9l6BvCJs29vlZlk'
# # api_key = 'vknq96vBmFZyBpFgMrOJ7HNVhlnO1qJSs2Kdyg40WNO2oudQSWEFAmwAQYrEIm0L'
# # api_secret = 'qQdTKB4wEyjRKWJwpM8CW9sRWjIGPBeODa34LRYlJtGbl4kaF9l6BvCJs29vlZlk'

# # Initialize the Binance client for testnet
# client = Client(API_KEY, API_SECRET, testnet=True)

# @app.route('/webhook', methods=['POST'])
# def webhook():
#     data = request.get_json()
#     symbol = data['symbol']
#     action = data['action'].lower()

#     if action == 'buy':
#         # Place market order
#         quantity = 0.1  # Define the quantity for the market order
#         order = client.order_market_buy(symbol=symbol, quantity=quantity)
#         print("Market Order Response:", order)

#         # Get balance (free and locked)
#         balance = client.get_asset_balance(asset='BTC')
#         print("Balance:", balance)

#         # Calculate quantities for TP and SL orders
#         tp_quantity = round(quantity / 3, 4)
#         sl_quantity = quantity

#         # Place TP limit orders
#         tp_prices = [data['tp1'], data['tp2'], data['tp3']]
#         for price in tp_prices:
#             tp_order = client.order_limit_sell(symbol=symbol, quantity=tp_quantity, price=price)
#             print(f"TP Order at {price}:", tp_order)

#         # Place SL order
#         sl_order = client.create_order(
#             symbol=symbol,
#             side=SIDE_SELL,
#             type=ORDER_TYPE_STOP_LOSS_LIMIT,
#             timeInForce=TIME_IN_FORCE_GTC,
#             quantity=sl_quantity,
#             stopPrice=data['sl'],
#             price=data['sl']
#         )
#         print("SL Order:", sl_order)

#     elif action == 'sell':
#         # Cancel all open orders
#         open_orders = client.get_open_orders(symbol=symbol)
#         for order in open_orders:
#             client.cancel_order(symbol=symbol, orderId=order['orderId'])

#         # Optionally close all positions by market sell
#         balance = client.get_asset_balance(asset=symbol.replace('USDT', ''))
#         if float(balance['free']) > 0:
#             order = client.order_market_sell(symbol=symbol, quantity=float(balance['free']))
#             print("Closing Order:", order)

#     return jsonify({'status': 'completed'})

# if __name__ == '__main__':
#     app.run(debug=True)




# from flask import Flask, request, jsonify
# from binance.client import Client
# from binance.enums import *

# app = Flask(__name__)

# # Use your Binance testnet API key and secret here
# API_KEY = 'vknq96vBmFZyBpFgMrOJ7HNVhlnO1qJSs2Kdyg40WNO2oudQSWEFAmwAQYrEIm0L'
# API_SECRET = 'qQdTKB4wEyjRKWJwpM8CW9sRWjIGPBeODa34LRYlJtGbl4kaF9l6BvCJs29vlZlk'

# # Initialize the Binance client for testnet
# client = Client(API_KEY, API_SECRET, testnet=True)

# def square_off_positions_and_close_orders(symbol):
#     # Cancel all open orders
#     open_orders = client.get_open_orders(symbol=symbol)
#     for order in open_orders:
#         client.cancel_order(symbol=symbol, orderId=order['orderId'])
    
#     # Optionally close all positions by market sell
#     balance = client.get_asset_balance(asset=symbol.replace('USDT', ''))
#     if float(balance['free']) > 0:
#         client.order_market_sell(symbol=symbol, quantity=format(float(balance['free']), '.4f'))
#         print("Closed all positions for", symbol)

# @app.route('/webhook', methods=['POST'])
# def webhook():
#     data = request.get_json()
#     symbol = data['symbol']
#     action = data['action'].lower()

#     # Clear all existing positions and orders before processing new action
#     square_off_positions_and_close_orders(symbol)

#     if action == 'buy':
#         # Place market order
#         usdt_balance = client.get_asset_balance(asset='USDT')
#         quantity = format(float(usdt_balance['free']), '.4f')  # Define the quantity for the market order

#         if float(usdt_balance['free']) > 0:
#             order = client.order_market_buy(symbol=symbol, quantity=quantity)
#             print("Market Order Response:", order)

#             # Get balance (free and locked)
#             btc_balance = client.get_asset_balance(asset='BTC')
#             print("BTC Balance:", btc_balance)

#             # Calculate quantities for TP and SL orders
#             tp_quantity = format(float(quantity) / 3, '.4f')
#             sl_quantity = format(float(quantity), '.4f')

#             # Place TP limit orders
#             tp_prices = [data['tp1'], data['tp2'], data['tp3']]
#             for price in tp_prices:
#                 tp_order = client.order_limit_sell(symbol=symbol, quantity=tp_quantity, price=price)
#                 print(f"TP Order at {price}:", tp_order)

#             # Place SL order
#             sl_order = client.create_order(
#                 symbol=symbol,
#                 side=SIDE_SELL,
#                 type=ORDER_TYPE_STOP_LOSS_LIMIT,
#                 timeInForce=TIME_IN_FORCE_GTC,
#                 quantity=sl_quantity,
#                 stopPrice=data['sl'],
#                 price=data['sl']
#             )
#             print("SL Order:", sl_order)
#         else:
#             print("Insufficient USDT balance to execute buy order.")

#     return jsonify({'status': 'completed'})

# if __name__ == '__main__':
#     app.run(debug=True)



from flask import Flask, request, jsonify
from binance.client import Client
from binance.enums import *
import time

app = Flask(__name__)
API_KEY = 'vknq96vBmFZyBpFgMrOJ7HNVhlnO1qJSs2Kdyg40WNO2oudQSWEFAmwAQYrEIm0L'
API_SECRET = 'qQdTKB4wEyjRKWJwpM8CW9sRWjIGPBeODa34LRYlJtGbl4kaF9l6BvCJs29vlZlk'
# api_key = 'vknq96vBmFZyBpFgMrOJ7HNVhlnO1qJSs2Kdyg40WNO2oudQSWEFAmwAQYrEIm0L'
# api_secret = 'qQdTKB4wEyjRKWJwpM8CW9sRWjIGPBeODa34LRYlJtGbl4kaF9l6BvCJs29vlZlk'

# Initialize the Binance client for testnet
client = Client(API_KEY, API_SECRET, testnet=True)

@app.route('/webhook', methods=['POST'])
def webhook():
    start_time = time.time() 
    data = request.get_json()
    symbol = data['symbol']
    action = data['action'].lower()

    if action == 'buy':
        # Place market order
        quantity = 0.1  # Define the quantity for the market order
        order = client.order_market_buy(symbol=symbol, quantity=quantity)
        print("Market Order Response:", order)

        # Get balance (free and locked)
        balance = client.get_asset_balance(asset='BTC')
        print("Balance:", balance)

        # Calculate quantities for TP and SL orders
        tp_quantity = round(quantity / 3, 4)
        sl_quantity = quantity

        # Place TP limit orders
        tp_prices = [data['tp1'], data['tp2'], data['tp3']]
        for price in tp_prices:
            tp_order = client.order_limit_sell(symbol=symbol, quantity=tp_quantity, price=price)
            print(f"TP Order at {price}:", tp_order)

        # Place SL order
        # sl_order = client.create_order(
        #     symbol=symbol,
        #     side=SIDE_SELL,
        #     type=ORDER_TYPE_STOP_LOSS_LIMIT,
        #     timeInForce=TIME_IN_FORCE_GTC,
        #     quantity=sl_quantity,
        #     stopPrice=data['sl'],
        #     price=data['sl']
        # )
        # print("SL Order:", sl_order)
        end_time = time.time()
        print(f"Total time taken : {end_time-start_time:.4f} Seconds")
    elif action == 'sell':
        # Cancel all open orders
        open_orders = client.get_open_orders(symbol=symbol)
        for order in open_orders:
            client.cancel_order(symbol=symbol, orderId=order['orderId'])

        # Optionally close all positions by market sell
        balance = client.get_asset_balance(asset=symbol.replace('USDT', ''))
        if float(balance['free']) > 0:
            order = client.order_market_sell(symbol=symbol, quantity=float(balance['free']))
            print("Closing Order:", order)

    return jsonify({'status': 'completed'})

if __name__ == '__main__':
    app.run(debug=True)




# API Key
# a3ea74bfe08b3b427c3f76902d30d84b4c0d9fd735857b8a318e1bc4b0a004e2
# API Secret
# 97782ad4220f7c3dfdecab1e5adf09084e2f9afb7d9f6e1f1249eaf1f2007060    
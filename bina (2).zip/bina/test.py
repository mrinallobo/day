import csv
from flask import Flask, request, render_template
from binance.client import AsyncClient
from binance.enums import *

app = Flask(__name__)

USER_FILE = 'users.csv'

def load_users():
    users = []
    try:
        with open(USER_FILE, 'r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                # Convert accountPercentage to float when loading
                row['accountPercentage'] = float(row['accountPercentage']) 
                users.append(row)
    except FileNotFoundError:
        pass
    return users

def save_users(users):
    with open(USER_FILE, 'w', newline='') as file:
        fieldnames = ['username', 'api_key', 'api_secret', 'trading_preference', 'accountPercentage']
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(users)

async def get_user_client(api_key, api_secret):
    return AsyncClient(api_key, api_secret)

async def place_spot_order(client, symbol, side, quantity):
    try:
        order = await client.create_order(
            symbol=symbol,
            side=side,
            type=ORDER_TYPE_MARKET,
            quantity=quantity
        )
        print(f"Spot order placed: {order}")
    except Exception as e:
        print(f"Error placing spot order: {e}")

async def place_futures_order(client, symbol, side, quantity):
    try:
        order = await client.futures_create_order(
            symbol=symbol,
            side=side,
            type=ORDER_TYPE_MARKET,
            quantity=quantity
        )
        print(f"Futures order placed: {order}")
    except Exception as e:
        print(f"Error placing futures order: {e}")

async def close_futures_position(client, symbol):
    try:
        positions = await client.futures_position_information(symbol=symbol)
        for position in positions:
            if float(position['positionAmt']) != 0:
                side = SIDE_BUY if position['positionSide'] == 'SHORT' else SIDE_SELL
                quantity = abs(float(position['positionAmt']))
                order = await client.futures_create_order(
                    symbol=symbol,
                    side=side,
                    type=ORDER_TYPE_MARKET,
                    quantity=quantity
                )
                print(f"Futures position closed: {order}")
    except Exception as e:
        print(f"Error closing futures position: {e}")

@app.route('/')
async def index():
    users = load_users()
    return render_template('index.html', users=users)

@app.route('/add_user', methods=['POST'])
async def add_user():
    try:
        username = request.form['username']
        api_key = request.form['apiKey']
        api_secret = request.form['apiSecret']
        trading_preference = request.form['tradingPreference']
        # Get account percentage from the form
        account_percentage = float(request.form['accountPercentage'])

        user = {
            'username': username,
            'api_key': api_key,
            'api_secret': api_secret,
            'trading_preference': trading_preference,
            'accountPercentage': account_percentage 
        }

        users = load_users()
        users.append(user)
        save_users(users)

        return {'success': True}, 200
    except KeyError as e:
        return {'error': f'Missing field: {e.args[0]}'}, 400
    except ValueError:
        return {'error': 'Invalid account percentage. Please enter a number.'}, 400

@app.route('/remove_user', methods=['POST'])
async def remove_user():
    data = request.get_json()
    index = data['index']

    users = load_users()
    users.pop(index)
    save_users(users)

    return {'success': True}

@app.route('/user_list')
async def user_list():
    users = load_users()
    return {'users': users}

@app.route('/webhook', methods=['POST'])
async def handle_webhook():
    data = await request.get_json()
    action = data['action']
    symbol = data['symbol']

    users = load_users()
    for user in users:
        client = await get_user_client(user['api_key'], user['api_secret'])

        # --- Calculate quantity based on account percentage ---
        account_balance = await client.futures_account_balance()  # You might need to adjust this based on your account type
        balance_to_use = float(next((bal['balance'] for bal in account_balance if bal['asset'] == 'USDT'), 0)) * (user['accountPercentage'] / 100)
        quantity = balance_to_use /1 # ... (Logic to calculate quantity based on balance, symbol price, etc.) ...

        if action == 'buy':
            if user['trading_preference'] == 'both' or user['trading_preference'] == 'long':
                await place_spot_order(client, symbol, SIDE_BUY, quantity)
        elif action == 'sell':
            if user['trading_preference'] == 'both' or user['trading_preference'] == 'short':
                await place_futures_order(client, symbol, SIDE_SELL, quantity)
        elif action == 'exit_long' or action == 'exit_short':
            await close_futures_position(client, symbol)

    return 'Webhook received'

if __name__ == '__main__':
    app.run()
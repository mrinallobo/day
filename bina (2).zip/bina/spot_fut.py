from flask import Flask, request
from binance import AsyncClient, BinanceSocketManager
from binance.enums import *
import aiohttp

app = Flask(__name__)

# API Keys for Testnet - Replace these with your actual testnet keys
spot_api_key = 'YOUR_SPOT_TESTNET_API_KEY'
spot_api_secret = 'YOUR_SPOT_TESTNET_API_SECRET'
futures_api_key = 'YOUR_FUTURES_TESTNET_API_KEY'
futures_api_secret = 'YOUR_FUTURES_TESTNET_API_SECRET'

# Setup clients for both spot and futures
spot_client = None
futures_client = None

async def init_clients():
    global spot_client, futures_client
    spot_client = await AsyncClient.create(spot_api_key, spot_api_secret, testnet=True)
    futures_client = await AsyncClient.create(futures_api_key, futures_api_secret, testnet=True)

@app.before_first_request
def initialize():
    app.ainit = init_clients()

async def place_spot_order(symbol, quantity):
    """Place a spot market order for buying."""
    order = await spot_client.create_order(
        symbol=symbol,
        side=SIDE_BUY,
        type=ORDER_TYPE_MARKET,
        quantity=quantity
    )
    return order

async def place_futures_order(symbol, quantity):
    """Place a futures market order for selling."""
    order = await futures_client.futures_create_order(
        symbol=symbol,
        side=SIDE_SELL,
        type=ORDER_TYPE_MARKET,
        quantity=quantity
    )
    return order

@app.route('/webhook', methods=['POST'])
async def handle_webhook():
    data = await request.get_json()
    action = data.get('action')  # Expected to be 'buy' or 'sell'
    symbol = data.get('symbol')  # Expected to be something like 'BTCUSDT'
    quantity = data.get('quantity', 0.001)  # Default quantity or from the webhook

    # Validate the received data
    if not action or not symbol:
        return "Invalid data", 400

    # Execute orders based on the action and symbol received from the webhook
    if action == 'buy':
        order_response = await place_spot_order(symbol, quantity)
        result = f"Spot Buy Order Response: {order_response}"
    elif action == 'sell':
        order_response = await place_futures_order(symbol, quantity)
        result = f"Futures Sell Order Response: {order_response}"
    else:
        return "Unsupported action", 400

    return result

if __name__ == "__main__":
    app.run(debug=True, use_reloader=False)
